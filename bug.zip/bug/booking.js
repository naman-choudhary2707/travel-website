const destinationSelect = document.getElementById('destination');
const priceDisplay = document.getElementById('price');

// Update price based on selected destination
destinationSelect.addEventListener('change', function() {
    const selectedValue = destinationSelect.value;

    let price = 0;
    switch (selectedValue) {
        case 'Uttarakhand':
            price = 1500;
            break;
        case 'Rajasthan':
            price = 2000;
            break;
        case ' Goa':
            price = 1800;
            break;
     
    }
    priceDisplay.textContent = Price;₹₹{price};
});

// Handle form submission
document.getElementById('booking-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Booking Confirmed! We will contact you soon.');
});